# SSD2541 Test Example


## Overview

This example demonstrates `SSD2541_getPoint(args)` with coordinates of your finger detected with pressure.

### Hardware Required

SSD2805+SSD2541 demo kit with ESP32-Pico-kit.

#### Pin Assignment:
SDA : GPIO21<br>
SCL : GPIO22<br>
IRQ : GPIO35 (not used in this demo)<br>
RST : GPIO10 (share with SSD2805 for hw reset)<br>

### Build and Flash
Get ESP32 IDF installed according to [https://docs.espressif.com/projects/esp-idf/en/latest/get-started/index.html](https://docs.espressif.com/projects/esp-idf/en/latest/get-started/index.html) and make sure *IDF_PATH* has been set correctly. Copy this folder to any place at your convenience. Launch `mingw32.exe`and browse to the root folder where `Makefile` is located. Type make menuconfig, browse to Serial flasher config ---> set COM port to your development environment. In my case it is COM6 (using Windows 7 Pro). Press EXIT twice, and click <YES> to save configuration. From $ prompt, type `make flash`. After program download, open a serial terminal e.g. Serial Monitor of Arduino IDE, set it to 115200bps. Touch the screen with different pressure to feel it. Observe the coordinates returned.

## Example Output
