/* i2c - Example

   For other examples please check:
   https://github.com/espressif/esp-idf/tree/master/examples

   See README.md file to get detailed usage of this example.

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include "SSD2541.h"

void app_main()
{

	int16_t finger_x=0, finger_y=0;
	uint8_t pressure = 0;
	SSD2541_begin();
	uint16_t deviceId = SSD2541_readDeviceId();

	printf("Device ID is 0x%x\n", deviceId);

	for(;;){
		vTaskDelay(30/portTICK_PERIOD_MS);
		SSD2541_getPoint(&finger_x, &finger_y, &pressure);
		printf("Touch x,y = %d , %d , %d\n", finger_x, finger_y, pressure);
	}
}
