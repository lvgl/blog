# LittlevGL example with SSD2805 + SSD2541 CTP driver

This is a simple demo use use a 240*240 mipi display for iPod Nano6 with LittlevGL
Pictures downloaded from https://pixabay.com/en/

