/**
 * @brief   This example demonstrates several LittlevGL features including label, button, and image display.
 *			The LCD is a 240*240 2 lane MIPI LCD driven by a bridge IC SSD2805. 
 *			Capacitive Touch Panel (CTP) is driven by SSD2541. 
 *			Only one API function is required for each driver, they are:
 *			SSD2805_dispFlush(args) for LCD
 *			SSD2541_getPoint(args) for CTP
 * 
 *
 */

#include "lvgl.h"
#include "SSD2805_8080_drv.h"
#include "SSD2541.h"
#include "esp_freertos_hooks.h" //for esp_register_freertos_tick_hook()


lv_obj_t * dynamic_label;
lv_obj_t *img;

LV_IMG_DECLARE(child);  //images of 240*240 in c array converted by an online tool at https://littlevgl.com/image-to-c-array
LV_IMG_DECLARE(polynesia);
LV_IMG_DECLARE(cat);

/**
 * @brief   API for LittlevGL with LV_VDB_SIZE!=0 in lv_conf.h
 */ 
static void ex_disp_flush(int32_t x1, int32_t y1, int32_t x2, int32_t y2, const lv_color_t * color_p)
{
    SSD2805_dispFlush(x1, y1, x2, y2, (const uint16_t*)color_p);
    lv_flush_ready();
}

/**
 * @brief   Heart beat for LittlevGL
 */ 
static void lv_tick_task(void)
{
    lv_tick_inc(portTICK_RATE_MS);
}

/**
 * @brief   API for touch screen
 */  
static bool ex_tp_read(lv_indev_data_t * data)
{
    int16_t ctp_x, ctp_y;
    bool sta = SSD2541_getPoint(&ctp_x, &ctp_y, NULL);

    (sta==true)? (data->state = LV_INDEV_STATE_REL):(data->state = LV_INDEV_STATE_PR);
    
    data->point.x = ctp_x;
    data->point.y = ctp_y;

    return false;
}

/**
 * @brief   Callback fcn for button
 */ 
static lv_res_t btn_click_action(lv_obj_t * btn)
{
    uint8_t id = lv_obj_get_free_num(btn);
	static uint8_t evt=0;
	static bool img_created = false;
	char str[255];
	
    printf("Button %d is released\n", id);
    
    sprintf(str, "Button clicked... %d", evt++);

    /* The button is released.
     * change text for a label as an example */
    lv_label_set_text(dynamic_label, str);
	
	if(evt == 5)
	{
		if(!img_created) 
		{
			img = lv_img_create(lv_scr_act(), NULL); 
			img_created = true;
		}
    lv_img_set_src(img, &child);
    lv_obj_align(img, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 0);
	}
	else if (evt == 6)
	{
	lv_img_set_src(img, &polynesia);
    lv_obj_align(img, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 0);
	}
	else if (evt == 7)
	{
	lv_img_set_src(img, &cat);
    lv_obj_align(img, NULL, LV_ALIGN_IN_TOP_LEFT, 0, 0);	
	evt = 4;
	}
    return LV_RES_OK; /*Return OK if the button is not deleted*/
}

void app_main()
{
    SSD2805_begin();
    SSD2541_begin();
    lv_init();
    
    lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.disp_flush = ex_disp_flush;
    lv_disp_drv_register(&disp_drv);

    lv_indev_drv_t indev_drv;                       /*Descriptor of an input device driver*/
    lv_indev_drv_init(&indev_drv);                  /*Basic initialization*/
    indev_drv.type = LV_INDEV_TYPE_POINTER;         /*The touchpad is pointer type device*/
    indev_drv.read = ex_tp_read;                    /*Library ready your touchpad via this function*/
    lv_indev_drv_register(&indev_drv);              /*Finally register the driver*/

    esp_register_freertos_tick_hook(lv_tick_task);


    /*Create a title label*/
    lv_obj_t * label = lv_label_create(lv_scr_act(), NULL);
    lv_label_set_text(label, "Hello LittlevGL");
    lv_obj_align(label, NULL, LV_ALIGN_CENTER, 0, 5);

    /*Create a normal button*/
    lv_obj_t * btn1 = lv_btn_create(lv_scr_act(), NULL);
    lv_cont_set_fit(btn1, true, true); /*Enable resizing horizontally and vertically*/
    lv_obj_align(btn1, lv_scr_act(), LV_ALIGN_IN_BOTTOM_LEFT, 0, 0);
    lv_obj_set_free_num(btn1, 1);   /*Set a unique number for the button*/
    lv_btn_set_action(btn1, LV_BTN_ACTION_CLICK, btn_click_action);

    /*Add a label to the button*/
    label = lv_label_create(btn1, NULL);
    lv_label_set_text(label, "Click me");

    dynamic_label = lv_label_create(lv_scr_act(), NULL);
    lv_label_set_text(dynamic_label, "Click to change...");
    lv_obj_align(dynamic_label, NULL, LV_ALIGN_IN_TOP_MID, 0, 50);      /*Align to center*/

    for(;;){
        vTaskDelay(1);
        lv_task_handler();
    }
}