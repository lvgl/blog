// Copyright 2015-2016 Espressif Systems (Shanghai) PTE LTD
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#ifndef __I2S_H__
#define __I2S_H__

#define CONFIG_BIT_MODE_8BIT	//use 8-bit 8080

#define I2S0_FIFO_ADD 0x6000f000
#define I2S1_FIFO_ADD 0x6002d000
//This macro definition only for lcd and camera mode.
//In i2s dma link descriptor, the maximum of dma buffer is 4095 bytes,
//so we take the length of 1023 words here.
#define DMA_SIZE (2000)  //words

#include "driver/i2s.h"
#include "esp_err.h"
#include <esp_types.h>

typedef struct {
    int     data_width;          /*!< Parallel data width, 16bit or 8bit available */
    uint8_t data_io_num[16];     /*!< Parallel data output IO*/
    int     ws_io_num;           /*!< write clk io*/
    int     rs_io_num;           /*!< rs io num */
} i2s_lcd_config_t;

typedef struct {
    i2s_lcd_config_t i2s_lcd_conf;/*!<I2S lcd parameters */
    i2s_port_t i2s_port;          /*!<I2S port number */
} i2s_lcd_t;

typedef void* i2s_lcd_handle_t;

typedef enum lcd_orientation{
    LCD_DISP_ROTATE_0 = 0,
    LCD_DISP_ROTATE_90 = 1,
    LCD_DISP_ROTATE_180 = 2,
    LCD_DISP_ROTATE_270 = 3,
} lcd_orientation_t;

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief I2S lcd bus create
 *
 * @param i2s_num i2s_port_t
 * @param pin_conf i2s pin configuration
 * 
 * @return
 *     - ESP_OK Success
 *     - ESP_FAIL Failed
 */
i2s_lcd_handle_t i2s_lcd_create(i2s_port_t i2s_num, i2s_lcd_config_t *pin_conf);

/**
 * @brief Write byte data.
 *
 * @param i2s_lcd_handle_t i2s_lcd_handle
 * @param src will write data
 * @param size data length in bytes
 * @param ticks_to_wait The maximum amount of time the task should block
 * waiting for an item to receive should the queue be empty at the time
 * of the call.	 xQueueReceive() will return immediately if xTicksToWait
 * is zero and the queue is empty.  The time is defined in tick periods so the
 * constant portTICK_PERIOD_MS should be used to convert to real time if this is
 * required.
 * @param swap swap high/low byte
 * 
 * @return
 *      - write data length
 * @note    No CS# strob with this function
 */
int i2s_lcd_write_data(i2s_lcd_handle_t i2s_lcd_handle, const char *src, size_t size, TickType_t ticks_to_wait, bool swap);

/**
 * @brief   Send a single byte as command with RS wire strobe LOW.
 * @param   i2s_lcd_handle_t i2s_lcd_handle
 * @param   cmd is the command to send in 8 bit
 * @note    No CS# strobe with this function
 */ 
void i2s_lcd_write_cmd(i2s_lcd_handle_t i2s_lcd_handle, uint8_t cmd);

/**
 * @brief   Set WR# frequency by changing the BCK divisor
 * @param   i2s_lcd_handle 
 * @param   div >=2 with WR# freq. calculation shown below:
 *          f(i2s) = f(pll)/(N+(b/a)), N>=2 is the REG_CLKM_DIV_NUM[7:0]
 *          b=I2S_CLKM_DIV_B[5:0], a=I2S_CLKM_DIV_A[5:0]
 * 
 *          Bit clock BCK f(bck) = f(i2s)/M, M>=2 is the I2S_TX_BCK_DIV_NUM[5:0].
 *          In LCD mode, WR# freq = f(bck)/2
 * 
 *          So, WR# freq = f(pll)/(N+(b/a))/M/2 = f(pll)/(clkm_div_num+(b/a))/(tx_bck_div_num)/2
 *          Max. WR# freq = 160MHz/8=20MHz clock (good for SSD2805 when PLL has been enabled)
 * 
 *          @tx_bck_div_num=16, WR# freq = 160MHz/2/16/2=2.5MHz (good for SSD2805 when PLL is not enabled)
 *          Basic clock setup in i2s_set_parallel_mode(i2s_port_t i2s_num) with clkm_div_num=2, clkm_div_b=0 for simplcity
 */
void i2s_set_bck_div_num(i2s_lcd_handle_t i2s_lcd_handle, uint8_t div);

#ifdef __cplusplus
}
#endif

#endif //__I2S_H__
