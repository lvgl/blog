/**
 * @brief     SSD2805 driver
 * @processor esp32 + SSD2805 + 1.54" 240*240 mipi LCD (LG LH154Q01)
 * @Compiler  ESP32 IDF
 * @note      Reference : https://github.com/espressif/esp-iot-solution
 *            Inside there is a component i2s_devices for 8080 8/16-bit parallel bus driver
 *            https://github.com/espressif/esp-iot-solution/tree/master/components/i2s_devices/lcd_common
 * 
 * Only 16 bit per pixel is supported in 565 color format R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0
 * Interface is a 8-bit 8080 parallel bus
 * Programmer : John Leung @ TechToys Co. Hong Kong (www.TechToys.com.hk)
 * Date: 2018-01-07
 */

#include "SSD2805_8080_drv.h"

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

static i2s_lcd_handle_t ssd2805;

/**
 * @brief   Manually set CS pin, only valid for 8080 parallel bus. 
 *          GPIO should be set to digital output previously.
 */ 
static inline void setCS(bool v)
{
    (v==1)?(gpio_set_level((gpio_num_t)LCD_CS_PIN,1)):(gpio_set_level((gpio_num_t)LCD_CS_PIN,0));
}

/**
 * @brief   Manually set RESET pin.
 */ 
static void setRST(bool v)
{
    (v==1)?(gpio_set_level((gpio_num_t)LCD_RST_PIN,1)):(gpio_set_level((gpio_num_t)LCD_RST_PIN,0));
}

/**
 * @brief Write a single byte as command with CS# strobed. 
 *        For SPI CS# strobed is auto. For 8080 CS# strobed by GPIO toggle.
 * @param cmd is the command to send
 */
static void writeCmd(uint8_t cmd)
{
    setCS(0);   //chip select with i2s 8080 LCD is not automatic. Need to do it manually
    i2s_lcd_write_cmd(ssd2805, cmd);
    setCS(1);
}

static void writeRegister(uint8_t reg, const uint8_t *data8, uint32_t len)
{
    setCS(0);   //chip select with i2s 8080 LCD is not automatic. Need to do it manually
    i2s_lcd_write_cmd(ssd2805, reg);
    if(len!=0){
    i2s_lcd_write_data(ssd2805, (const char *)data8, len, 100, false);
    }
    setCS(1);
}

/**
 * @brief Set packet size sending to mipi display in byte count
 */ 
static void setTDCSize(uint32_t byteCount)
{
    uint8_t txbuffer[2];
    txbuffer[0] = (uint8_t)byteCount;
    txbuffer[1] = (uint8_t)(byteCount>>8);

    writeRegister(0xbc, (const uint8_t *)&txbuffer, 2); //Set packet size TDC[15:0]

    txbuffer[0] = (uint8_t)(byteCount>>16);
    txbuffer[1] = (uint8_t)(byteCount>>24);   

    writeRegister(0xbd, (const uint8_t *)&txbuffer, 2); //Set packet size TDC[31:16]
}

/**
 * @brief Set the area to draw on LCD
 * @param (x2,y2) is the top left corner coordinates, (x1,y1) is the lower right corner
 * @return 0 if failed, 1 if successful
 */
static bool setRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
  if((x1>x2) || (y1>y2)) return 0;

  uint8_t txbuffer[4];
  
  uint16_t sc = min(x1, DISP_HOR_SIZE-1);
  uint16_t sp = min(y1, DISP_VER_SIZE-1);
  uint16_t ec = min(x2, DISP_HOR_SIZE-1);
  uint16_t ep = min(y2, DISP_VER_SIZE-1);
    
  setTDCSize(4);

  txbuffer[0] = (uint8_t)(sc>>8);  //SC[15:8]  start column
  txbuffer[1] = (uint8_t)sc;       //SC[7:0]
  txbuffer[2] = (uint8_t)(ec>>8);  //EC[15:8] end column
  txbuffer[3] = (uint8_t)ec;       //EC[7:0] 
  writeRegister(DCS_COL_SET, (const uint8_t *)&txbuffer, 4);

  txbuffer[0] = (uint8_t)(sp>>8); //SP[15:8]  start page
  txbuffer[1] = (uint8_t)sp;      //SP[7:0]
  txbuffer[2] = (uint8_t)(ep>>8); //EP[15:8] end page
  txbuffer[3] = (uint8_t)ep;      //EP[7:0]
  writeRegister(DCS_PAGE_SET, (const uint8_t *)&txbuffer, 4);

  return 1;
}


/**
 * @brief Like conventional Arduino driver, thie begin() method should be called before using D2805
 */ 
void SSD2805_begin(void)
{
    //HW reset with GPIO 
    gpio_set_direction((gpio_num_t)LCD_RST_PIN, (gpio_mode_t)GPIO_MODE_OUTPUT);
    gpio_set_direction((gpio_num_t)LCD_CS_PIN, (gpio_mode_t)GPIO_MODE_OUTPUT);
    gpio_set_pull_mode((gpio_num_t)LCD_CS_PIN, (gpio_pull_mode_t)GPIO_PULLUP_ONLY);
    gpio_set_direction((gpio_num_t)LCD_DC_PIN, (gpio_mode_t)GPIO_MODE_OUTPUT);
    gpio_set_pull_mode((gpio_num_t)LCD_DC_PIN, (gpio_pull_mode_t)GPIO_PULLUP_ONLY);

    i2s_lcd_config_t ssd2805_conf = {
        8,	//data_width = 8
        {
            LCD_D0_PIN, LCD_D1_PIN, LCD_D2_PIN, LCD_D3_PIN,
            LCD_D4_PIN, LCD_D5_PIN, LCD_D6_PIN, LCD_D7_PIN
        },
        LCD_WR_PIN,
        LCD_DC_PIN
    };

    ssd2805 = i2s_lcd_create(I2S_PORT_NUM, &ssd2805_conf);  //default 2.5MHz WR# freq.

    //hardware reset. This is optional if you have an external reset IC onboard
    SSD2805_hwReset();  //toggle LCD_RST_PIN for hardware reset

    //Step 1: set PLL
    uint8_t txbuffer[12];
    txbuffer[0]=0x0f; txbuffer[1]=0x00;

    writeRegister(0xba, (const uint8_t *)&txbuffer, 2); //PLL 	= clock*MUL/(PDIV*DIV)
                                                        //		= clock*(BAh[7:0]+1)/((BAh[15:12]+1)*(BAh[11:8]+1))
                                                        //		= 20*(0x0f+1)/1*1 = 20*16 = 320MHz
                                                        //Remark: 350MHz >= fvco >= 225MHz for SSD2805 since the max. speed per lane is 350Mbps

    txbuffer[0]=0x01; txbuffer[1]=0x00;
    writeRegister(0xb9, (const uint8_t *)&txbuffer, 2);       //enable PLL
    
    vTaskDelay(2/portTICK_PERIOD_MS);  ;   //delay 2ms to wait for PLL stablize
  
    //Step 2: Now it is safe to set SPI up to 40MHz (remove it for now with strip wire prototype )
    //equivalent to calling SPI.setFrequency(40000000UL);   //now we can set SPI clock up to 40MHz (PLL clock=320/8)
    i2s_set_bck_div_num(ssd2805, 2);    //set WR# freq. to ~13MHz.
 
    //Step 3: set clock control register for SYS_CLK & LP clock speed
	  //SYS_CLK = TX_CLK/(BBh[7:6]+1), TX_CLK = external oscillator clock speed
	  //In this case, SYS_CLK = 20MHz/(1+1)=10MHz. Measure SYS_CLK pin to verify it.
	  //LP clock = PLL/(8*(BBh[5:0]+1)) = 320/(8*(4+1)) = 8MHz, conform to AUO panel's spec, default LP = 8Mbps
	  //S6D04D2 is the controller of AUO 1.54" panel.
    txbuffer[0]=0x44; txbuffer[1]=0x00;
    writeRegister(0xbb, (const uint8_t *)&txbuffer, 2);

    txbuffer[0]=0x00; txbuffer[1]=0x01;
    writeRegister(0xd6, (const uint8_t *)&txbuffer, 2);   //output sys_clk for debug. Now check sys_clk pin for 10MHz signal

    //Step 4: Set MIPI packet format
    txbuffer[0]=0x43; txbuffer[1]=0x02;
    writeRegister(0xb7, (const uint8_t *)&txbuffer, 2);   //EOT packet enable, write operation, it is a DCS packet
                                                    //HS clock is disabled, video mode disabled, in HS mode to send data

    //Step 5: set Virtual Channel (VC) to use
    txbuffer[0]=0x00; txbuffer[1]=0x00;
    writeRegister(0xb8, (uint8_t *)&txbuffer, 2);

	  //Step 6: Now write DCS command to AUO panel for system power-on upon reset
    setTDCSize(0);
    writeRegister(DCS_SLPOUT, NULL, 0);

    vTaskDelay(100/portTICK_PERIOD_MS);					//wait for AUO/LG  panel after sleepout(Important:cannot use delay(100)!)

    //Step 7: Now configuration parameters sent to AUO/LG panel for 16-bits/pixel
    setTDCSize(1);
    txbuffer[0] = 0x05;
    writeRegister(DCS_COLMOD, (const uint8_t *)&txbuffer, 1); //Set 0x3a to 0x05 (16-bit color)

    //Step 8: Set TE line and VBP time

    setTDCSize(2);
    txbuffer[0]=0x5A; txbuffer[1]=0x5A;
    writeRegister(0xF1, (const uint8_t *)&txbuffer, 2);  //unlock MCS
    

    //Set MCS register at 0xF2 to set VBP, VFP, and TE time
    //Setup here establishes a TE time sync. with VBP = 5.64ms with display time = 14.40ms
    //leading to a frame rate of 50fps. Calculation can be seen from an Excel sheet
    //Result verified with a DSO. This is a significant result as we may now sync with a slower mcu for flicker-free display.
    // *** Add support for TE and VBP time set here ***
    //Trying larger NVBP and NVFP values for slower framerate with blank time =25.56ms, display time =14.40ms
 
    setTDCSize(12);
    txbuffer[0]=0x00;     //NL=0x00 (default)
    txbuffer[1]=0xF0;     //NHW=0xF0 (default for 240 clocks per line)
    txbuffer[2]=0x03;     //frame inversion etc. leave it default
    txbuffer[3]=0x56;     //NVBP=0x56 (.86) for a vertical back porch in normal mode
    txbuffer[4]=0x08;     //NVFP=8 for a vertical front porch in normal mode
    txbuffer[5]=0x00;     //RSEL[1:0]=00 for 240x240 resolution
    txbuffer[6]=0x01;     //TE = ON
    txbuffer[7]=0x00;     //TE_ST set zero for TE signal starts on internal VS
    txbuffer[8]=0x00;
    txbuffer[9]=0x00;     //TE_ED set the same value as NVBP to synchronize with NVBP
    txbuffer[10]=0x56;
    txbuffer[11]=0x03;    //set TE line as active high
    writeRegister(0xF2, (const uint8_t *)&txbuffer, 12);  //Set DISPCTL for porch and TE values
  
    setTDCSize(2);
    txbuffer[0]=0xA5; txbuffer[1]=0xA5;
    writeRegister(0xF1, (const uint8_t *)&txbuffer, 2);  //lock MCS
    
    /*
    //Attempt to install isr for TE pin
    gpio_config_t io_conf;
    io_conf.intr_type = (gpio_int_type_t)GPIO_INTR_POSEDGE;
    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
    io_conf.pin_bit_mask = (1ULL<<PIN_NUM_TE);
    gpio_config(&io_conf);

    err = gpio_install_isr_service(ESP_INTR_FLAG_EDGE|ESP_INTR_FLAG_IRAM);
    assert(err==ESP_OK);
    err = gpio_isr_handler_add((gpio_num_t)PIN_NUM_TE, (gpio_isr_t)te_isr_handler, (void*)this);
    assert(err==ESP_OK);
    err = gpio_intr_disable((gpio_num_t)PIN_NUM_TE); 
    assert(err==ESP_OK);
    */

    setTDCSize(0);
    writeRegister(DCS_DISPON, NULL, 0);                  //display ON DCS command to AUO panel    
    
    SSD2805_clearLCD(0x0000); //clearLCD after DCS_DISPON if TE pin is to sync with MCU write
    //switch on backlight....
    //printf("SSD2805_begin() finished\n");
}

/**
 * @brief Toggle reset input for SSD2805
 */
void SSD2805_hwReset(void)
{
  setRST(0);
  vTaskDelay(300/portTICK_PERIOD_MS);
  setRST(1);
  vTaskDelay(10/portTICK_PERIOD_MS);
}

/**
 * @brief Clear the whole display with a color
 * @param color in 2 bytes per pixel (R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0)
 */ 
void SSD2805_clearLCD(uint16_t color)
{  
  SSD2805_dispFill(0,0,DISP_HOR_SIZE-1, DISP_VER_SIZE-1, color);
}


/**
 * @brief Fill display for a certain area with a color
 * @param (x2,y2) is the top left corner coordinates, (x1,y1) is the lower right corner 
 * @param color in 2 bytes per pixel (R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0)
 */ 
void SSD2805_dispFill(int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t color)
{
  if(!setRectangle(x1,y1,x2,y2)) return;
  
  uint32_t byteCount2Flush = (x2-x1+1)*(y2-y1+1)*2;
  //printf("dispFlush::byteCount2Flush = %d\n", byteCount2Flush);
  setTDCSize(byteCount2Flush);
  
  uint32_t dmaBlockCount = 0;
  if(byteCount2Flush >= MAX_DMA_LEN)
  {
    dmaBlockCount = byteCount2Flush/MAX_DMA_LEN; 
    //printf("dispFlush::byteCount2Flush > MAX_DMA_LEN so, dmaBlockCount = %d\n", dmaBlockCount);
  }
  
  byteCount2Flush%=MAX_DMA_LEN;  //byteCount2Flush becomes the remainder
  writeCmd(DCS_RAMWR);

    uint16_t *vdb = (uint16_t *)heap_caps_malloc(MAX_DMA_LEN, MALLOC_CAP_DMA);
    assert(vdb!=NULL);

    for(uint32_t i=0; i<MAX_DMA_LEN/2; i++)
        vdb[i] = color;

    setCS(0);   //chip select with i2s 8080 LCD is not automatic. Need to do it manually
    //cannot just do it like i2s_lcd_write_data(ssd2805, (const char *)&color, ...); otherwise, 
    //it will only be the first word sent with color but the remaining words all random!
    while(dmaBlockCount--){
        i2s_lcd_write_data(ssd2805, (const char *)vdb, MAX_DMA_LEN, (TickType_t)portMAX_DELAY, false);
    }
    
    if(byteCount2Flush){
        i2s_lcd_write_data(ssd2805, (const char *)vdb, byteCount2Flush, (TickType_t)portMAX_DELAY, false);
    }
    setCS(1);

    free(vdb);
}

/**
 * @brief Fill display for a certain area with data from flash
 * @param (x2,y2) is the top left corner coordinates, (x1,y1) is the lower right corner
 * @param *color_p is a pointer to data from Flash
 * @note  SSD2805 configure in 64k color
 *        1st write G2G1G0B4B3B2B1B0  green_l:3 blue:5
 *        2nd write R4R3R2R1R0G5G4G3  red:5 green_h:3
 *        e.g. uint16_t vdb[4] = {0xABCD, 0x1234, 0x5678, 0xaab6};  //color arranged in R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0
 *        SPI send in 8-bit in this order
 *        CDh->ABh->34h->12h->78h->56h->B6h->AAh
 */
void SSD2805_dispFlush(int32_t x1, int32_t y1, int32_t x2, int32_t y2, const uint16_t* color_p)
{
  if(!setRectangle(x1,y1,x2,y2)) return;

  uint32_t byteCount2Flush = (x2-x1+1)*(y2-y1+1)*2;

  setTDCSize(byteCount2Flush);
  
  uint32_t dmaBlockCount = 0;
  if(byteCount2Flush >= MAX_DMA_LEN)
  {
    dmaBlockCount = byteCount2Flush/MAX_DMA_LEN; 
  }
  
  byteCount2Flush%=MAX_DMA_LEN;  //byteCount2Flush becomes the remainder
  writeCmd(DCS_RAMWR);

    setCS(0);   //chip select with i2s 8080 LCD is not automatic. Need to do it manually

    while(dmaBlockCount--){
        i2s_lcd_write_data(ssd2805, (const char *)color_p, MAX_DMA_LEN, (TickType_t)portMAX_DELAY, false);
        color_p+=(MAX_DMA_LEN/2);
    }
    
    if(byteCount2Flush){
        i2s_lcd_write_data(ssd2805, (const char *)color_p, byteCount2Flush, (TickType_t)portMAX_DELAY, false);
    }
    setCS(1);

}

