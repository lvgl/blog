# Hello World Example with MIPI bridge chip SSD2805 to drive a 240*240 MIPI LCD

This is a primitive demo to display a picture of AppleWatch from a static array. Host processor is a ESP32 Wifi/BLE SoC compiled with its official IDF.Hardware is an ESP32-Pico-kit connected to SSD2805 EVK + SSD2541 CTP demo board. Get ESP32 IDF installed according to [https://docs.espressif.com/projects/esp-idf/en/latest/get-started/index.html](https://docs.espressif.com/projects/esp-idf/en/latest/get-started/index.html) and make sure *IDF_PATH* has been set correctly. Copy the folder of this project to any place at your convenience. Connect USB of ESP32-Pico-kit to your PC. Launch `mingw32.exe` and browse to the root folder where `Makefile` is located. Type make menuconfig, browse to Serial flasher config ---> set COM port number matching your development environment. In my case it is COM6 (using Windows 7 Pro).   Press EXIT twice, and click <YES> to save configuration. From $ prompt, type `make flash`.

Only three functions are required for this demo to work:<br>
**(1)** `SSD2805_begin(void)` - like most arduino demos this function is to initialize the driver with parameters hard-coded inside. Therefore if you need to modify it for another display you will have to change this function.<br>
**(2)** `SSD2805_dispFlush(args)` - this function has been designed in accordance to format required to port LittlevGL. It fills an area defined by (x1,y1) ~ (x2,y2) with a static array stored in MCU Flash.<br> Data has been converted by a freeware lcd-image-converter ([http://www.riuson.com/lcd-image-converter](http://www.riuson.com/lcd-image-converter)) in 565 color format of `R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0`.<br>
**(3)** `SSD2805_clearLCD(args)` - this function clears the whole display with a single color. This is a special case of `SSD2805_dispFill(args)` which is not required in this demo. <br> 


Only 16 bit per pixel is supported in 565 color format `R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0`. Interface is a 8-bit 8080 parallel bus with driver modified from ESP32 github at [https://github.com/espressif/esp-iot-solution/tree/master/components/i2s_devices/lcd_common](https://github.com/espressif/esp-iot-solution/tree/master/components/i2s_devices/lcd_common).

