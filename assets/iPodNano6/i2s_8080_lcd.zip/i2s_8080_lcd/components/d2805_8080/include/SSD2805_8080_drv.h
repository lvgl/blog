/**
 * @brief     SSD2805 driver
 * @processor esp32 + SSD2805 + 1.54" 240*240 mipi LCD (LG LH154Q01)
 * @Compiler  ESP32 IDF
 * @note      Reference : https://github.com/espressif/esp-iot-solution
 *            Inside there is a component i2s_devices for 8080 8/16-bit parallel bus driver
 *            https://github.com/espressif/esp-iot-solution/tree/master/components/i2s_devices/lcd_common
 * 
 * Only 16 bit per pixel is supported in 565 color format R4R3R2R1R0G5G4G3 G2G1G0B4B3B2B1B0
 * Interface is a 8-bit 8080 parallel bus
 * Programmer : John Leung @ TechToys Co. Hong Kong (www.TechToys.com.hk)
 * Date: 2018-01-07
 */

#ifndef SSD2805_8080_DRV_H
#define SSD2805_8080_DRV_H

#define INTERFACE_BUS_8080

#include "stdio.h"
#include "stdint.h"
#include "stdbool.h"
#include "string.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "soc/soc.h"
#include "soc/dport_reg.h"
#include "i2s_lcd.h"

#define I2S_PORT_NUM	(0)
  
#define LCD_D0_PIN  (26)
#define LCD_D1_PIN  (27)
#define LCD_D2_PIN  (14) 
#define LCD_D3_PIN  (12)
#define LCD_D4_PIN  (13)
#define LCD_D5_PIN  (15)
#define LCD_D6_PIN  (2)
#define LCD_D7_PIN  (4)

#define LCD_WR_PIN    (32)
#define LCD_CS_PIN    (33)
#define LCD_DC_PIN    (25)      //data(1)/command(0) selection pin (for 8 Bit 4 Wire only)
#define LCD_RST_PIN   (10)      //manual reset pin for SSD2805

//DSC commands
#define DCS_NOP                 0x00
#define DCS_SWRESET             0x01    //soft reset
#define DCS_RDDPM               0x0A    //Read display power mode
#define DCS_RDDMADCTL           0x0B    //Read display MADCTL
#define DCS_RDDCOLMOD           0x0C    //Read Display COLMOD
#define DCS_RDDIM               0x0D    //Read display image mode
#define DCS_RDDSM               0x0E    //Read display signal mode
#define DCS_RDDSDR              0x0F    //Read display self-diagnostic result
#define DCS_SLPIN               0x10
#define DCS_SLPOUT              0x11
#define DCS_NORON               0x13    //Normal display mode on
#define DCS_INVOFF              0x20
#define DCS_INVON               0x21
#define DCS_DISPOFF             0x28
#define DCS_DISPON              0x29

#define DCS_COL_SET             0x2A
#define DCS_PAGE_SET            0x2B
#define DCS_RAMWR               0x2C    //command to transfer data from MPU to frame memory
#define DCS_RAMRD               0x2E
#define DCS_TE_OFF              0x34
#define DCS_TE_ON               0x35
#define DCS_MEM_ACC_CTL         0x36    //memory access control for frame buffer scanning direction etc
#define DCS_IDLE_MODE_OFF       0x38
#define DCS_IDLE_MODE_ON        0x39
#define DCS_COLMOD              0x3A    //interface pixel format set
#define DCS_RAMWRC              0x3C    //continue memory write after DCS_RAMWR
#define DCS_READ_MEMORY_CNTU    0x3E

//Display size (in pixels)
#define DISP_HOR_SIZE 240
#define DISP_VER_SIZE 240

#define MAX_DMA_LEN   DMA_SIZE     //setting a value 'too high' like 57600 will paralyze cowork with LittlevGL
                                   //reason behind is not known, maybe stack allocation failed something like that?
                                   //It has been found a value as 240*120 (28800) is good for SPI.
                                   //For 8080, follow DMA_SIZE defined in i2s_lcd.h is good.          

#ifdef __cplusplus
extern "C" {
#endif

void SSD2805_begin(void);
void SSD2805_hwReset(void);
void SSD2805_clearLCD(uint16_t color);
void SSD2805_dispFill(int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t color);
void SSD2805_dispFlush(int32_t x1, int32_t y1, int32_t x2, int32_t y2, const uint16_t* color_p);

#ifdef __cplusplus
}
#endif

#endif
